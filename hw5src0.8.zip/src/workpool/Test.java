package workpool;

import java.util.ArrayList;
import java.util.Stack;

public class Test {
    static int count = 0;
    /*
    Find the largest index k such that a[k] < a[k + 1]. If no such index exists, the permutation is the last permutation.
    Find the largest index l such that a[k] < a[l]. Since k + 1 is such an index, l is well defined and satisfies k < l.
    Swap a[k] with a[l].
    Reverse the sequence from a[k + 1] up to and including the final element a[n].
    */
    private static ArrayList<ArrayList<Integer>> permDFS(
            ArrayList<Integer> prefix, ArrayList<Integer> suffix,
            ArrayList<ArrayList<Integer>> output) {
        if(prefix == null) prefix = new ArrayList<Integer>();
        if(output == null) output = new ArrayList<ArrayList<Integer>>();
        if(suffix.size() == 1) {
            ArrayList<Integer> newElement = new ArrayList<Integer>(prefix);
            newElement.addAll(suffix);
            output.add(newElement);
            return output;
        }
        for(int i = 0; i < suffix.size(); i++) {
            ArrayList<Integer> newPrefix = new ArrayList<Integer>(prefix);
            newPrefix.add(suffix.get(i));
            ArrayList<Integer> newSuffix = new ArrayList<Integer>(suffix);
            newSuffix.remove(i);
            permDFS(newPrefix, newSuffix, output);
        }
        return output;
    }



    public static void main(String[] args) {
        ArrayList<Integer> a = new ArrayList<Integer>();
        for (int i = 0; i < 5; i++) {
            a.add(i);
        }

        for (ArrayList<Integer> ai : permDFS(null, a, null)) {
            System.out.println(ai);
        }




    }
}
